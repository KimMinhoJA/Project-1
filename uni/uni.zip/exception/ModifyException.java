package kosta.uni.exception;

public class ModifyException extends Exception{
	public ModifyException() {
		super();
	}
	
	public ModifyException(String message) {
		super(message);
	}
}
