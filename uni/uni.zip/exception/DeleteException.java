package kosta.uni.exception;

public class DeleteException extends Exception{
	public DeleteException() {
		super();
	}
	
	public DeleteException(String message) {
		super(message);
	}
}
