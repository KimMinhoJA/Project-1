package kosta.uni.view;

public class SuccessView {
	public static void successMessage(String message) {
		System.out.println(message);
	}
}
