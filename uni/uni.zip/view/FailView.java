package kosta.uni.view;

public class FailView {
	public static void errorMessage(String message) {
		System.out.println(message);
	}
}
