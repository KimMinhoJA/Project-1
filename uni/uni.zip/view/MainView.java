package kosta.uni.view;

public class MainView {
	public static void main(String[] args) {
		new MenuView().menu();
		
	}
}
